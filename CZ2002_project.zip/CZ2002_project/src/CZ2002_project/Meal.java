package CZ2002_project;

import java.io.Serializable;

public class Meal extends Menu implements Serializable {
	
	public enum MealType {
		MAINS, DRINKS, DESSERTS
	}
	
	//idk what this is lol, dk if I can change also
	//private static final long serialVersionUID
	
	private MealType type;
	
	public MealType getType() {
		return this.type;
	}
	public void setType(MealType type) {
		this.type = type;
	}
	
	public Meal(String name, double price, String description, MealType type) {
		super(name, price, description);
		this.type = type;
	}
}
