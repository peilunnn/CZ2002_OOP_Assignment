package CZ2002_project;

import java.io.Serializable;
import java.util.Calendar;

//import CZ2002_project.Order;

public class Invoice implements Serializable{

	//generate serialVersionUID;
	
	private int invoiceNo;
	private double gst;
	private static final double GST = (7/100);
	private double price;
	private double totalCost;
	private Calendar date;
	private Order order;
	
	public double getTotalCost() {
		return totalCost;
	}
	public Order getOrder() {
		return order;
	}
	public Calendar getDate() {
		return date;
	}
	
	private Invoice(Order order) {
		this.invoiceNo = Calendar.getInstance().hashCode();
		this.gst = Math.round(this.price * GST )//* 100.0) / 100.0;
		this.price = order.calculateRawTotal();
		this.totalCost = this.price + this.gst;
		this.order = order; 
		this.date = Calendar.getInstance();
	}
	
	private void printInvoice() {
		System.out.println("Invoice number: "+ this.invoiceNo);
		System.out.println("Date & time: "+ this.order.getDateAndTime());
		System.out.println("Items ordered: ");
		System.out.println(this.order);
		System.out.println("Total price: "+ price);
		System.out.println("GST charge: "+ gst);
		System.out.println("Subtotal: "+totalCost);
		//System.out.printf("Subtotal: %0.2f" , totalCost);
	}
}
