package CZ2002_project;

import java.io.Serializable;
import java.util.Calendar;

import classes.Table;
import classes.Table.TableStatus;

//import CZ2002_project.Table.TableStatus;

public class Reservation implements Serializable{
	
	//generate serialVersionUID
	
	private int reservationNo;
	private int pax;
	private Table tableToReserve;
	private Calendar startTime;
	private String custName;
	private int custContact;
	private boolean confirmed;
	
	public int getReservationNo(){ 
		return this.reservationNo; 
	}
	public int getPax(){ 
		return this.pax; 
	}
	public Table getReservationOfTable(){ 
		return this.tableToReserve; 
	}
	public Calendar getStartTime(){ 
		return this.startTime; 
	}
	public String getCustName(){ 
		return this.custName; 
	}
	public void setCustName(String name){ 
		this.custName = name; 
	}
	public int getCustContact(){ 
		return this.custContact; 
	}
	public void setCustContact(int contact) { 
		this.custContact = contact; 
	}
	public boolean getConfirmationStatus(){ 
		return this.confirmed; 
	}
	
	public Reservation(String customerName, int customerContact, int numPax, Calendar arrivalTime, Table reserveTable){
		this.reservationNo = Calendar.getInstance().hashCode();
		this.pax = pax;
		this.tableToReserve = tableToReserve;
		tableToReserve.addReservation(this);
		this.startTime = startTime;
		this.custName = custName;
		this.custContact = custContact;
		this.confirmed = false;
	}
	
	public void setConfirmed(){
		this.confirmed = true;
		this.tableToReserve.setTableStatus(StatusOfTable.OCCUPIED);
		this.tableToReserve.removeReservation(this);
	}
	
	public String toString(){
		return "Customer Name:" + this.customerName + "    Contact: " + this.customerContact + 
				"    Arrival time: " + this.arrivalTime.getTime() + "	 Reservation ID: "+ this.reservationID +
				"	 Table ID: "+ this.reserveTable.getTableId();
	}
}
