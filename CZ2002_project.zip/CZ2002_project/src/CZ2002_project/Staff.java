package CZ2002_project;

import java.io.Serializable;

public class Staff implements Serializable{
	
	//generate serialVersionUID
	
	private String empName;
	private int emp_ID;
	private char empGender;
	private String jobPosition;
	
	public String getEmpName(){ 
		return empName; 
	}
	public void setEmpName(String empName){ 
		this.empName = empName; 
	}
	public int getEmpID(){ 
		return emp_ID; 
	}
	public void setEmpID(int emp_ID){ 
		this.emp_ID = emp_ID; 
	}
	public char getEmpGender() {
		return this.empGender;
	}
	public void setEmpGender(char empGender){ 
		this.empGender = empGender; 
	}
	public String getJobPosition(){ 
		return jobPosition; 
	}
	public void setJobPositon(String jobPosition){ 
		this.jobPosition = jobPosition; 
	}
	
	public Staff(String empName, int emp_ID, char empGender, String jobPosition) {
		this.empName = empName;
		this.emp_ID = emp_ID;
		this.empGender = empGender;
		this.jobPosition = jobPosition;
	}
	
	private String toString() {
		return ("Employee ID: " + this.emp_ID 
				+ "    Name: " + this.empName 
				+ "    Job Title: " + this.jobPosition);
	}	
}
