package CZ2002_project;

import java.io.Serializable;

public class OrderList implements Serializable{
	
	//generate serialVersionUID
	
	private Menu dish;
	private double priceCharged;
	
	public OrderList(Menu dish) {
		this.dish = dish;
		this.priceCharged = dish.getPrice();
	}

	public String toString() {
		return this.getMenu().getName();
	}
	
	public Menu getMenu() {
		return this.dish
	}
	public double getPriceCharged(){ 
		return this.priceCharged; 
	}
}
