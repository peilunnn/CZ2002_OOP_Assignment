package CZ2002_project;

import java.io.Serializable;
import java.util.ArrayList;

import classes.Reservation;
import classes.Table.TableStatus;

public class Table implements Serializable{
	
	//generate serialVersionUID
	
	private int tableNo;
	private int seats;
	public enum StatusOfTable {EMPTY, OCCUPIED};
	private StatusOfTable status;
	private ArrayList<Reservation> madeReservation;
	
	public Table (int tableNo, int seats) {
		this.tableNo = tableNo;
		this.seats = seats;
		this.status	= StatusOfTable.EMPTY;
		this.madeReservation = new ArrayList<Reservation>();
	}
	
	public int getTableNo(){ 
		return tableNo; 
	}
	public int getSeats(){ 
		return seats; 
	}
	public StatusOfTable getTableStatus(){ 
		return status; 
	}
	public void setTableStatus(StatusOfTable status){ 
		this.status = status; 
	}
	public ArrayList<Reservation> getMadeReservation(){ 
		return this.madeReservation; 
	}
	public void removeReservation(Reservation reservation){ 
		this.madeReservation.remove(reservation); 
	}
	public void removeReservation(int count){ 
		this.madeReservation.remove(count); 
	}
	public void addReservation(Reservation reservation){ 
		this.madeReservation.add(reservation); 
	}
}
