package CZ2002_project;

import java.io.Serializable;

public abstract class Menu implements Serializable{
	
	////idk what this is lol, dk if I can change also
	//private static final long serialVersionUID = 1991173970229115074L;
	
	private String name;
	private String description;
	private double price;
	
	public void setName(String name){ 
		this.name = name; 
	}
	public String getName(){ 
		return this.name; 
	}
	public void setDescription(String description){ 
		this.description = description; 
	}
	public String getDescription(){ 
		return this.description; 
	}
	public void setPrice(double price){ 
		this.price = price; 
	}
	public double getPrice(){ 
		return this.price; 
	}
	
	public Menu(String name, double price, String description){
		this.name = name;
		this.price = price;
		this.description = description;
	}
}
