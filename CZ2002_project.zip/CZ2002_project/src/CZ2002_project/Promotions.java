package CZ2002_project;

import java.io.Serializable;
import java.util.ArrayList;
//import user_lib.ScannerExt;

import CZ2002_project.Meal;
import CZ2002_project.Menu;
import user_lib.ScannerExt;

public class Promotions extends Menu implements Serializable{
	
	//generate serialVersionUID
	
	private ArrayList<Meal> mealSet;
	public ArrayList<Meal> getMealSet(){ 
		return mealSet; 
	}
	
	public Promotions(String name , double price , String description) {
		super(name, price, description);
		this.mealSet = new ArrayList<Meal>();
	}
	
	public void addMeal(Meal meal){ 
		mealSet.add(meal); 
	}
	public void addMeal(ArrayList<Menu> mealMenu){
		int i = 0;
		System.out.println("What dish do you wish to add to the Promotion Package?");
		for (Menu menu : mealMenu){
			if(menu instanceof Meal)
				System.out.println("(" + i + ") " + menu.getName());
			i++;
		}
    	int option = ScannerExt.nextInt("    Enter your choice: ");
		try {
			if(mealMenu.get(option) instanceof Meal){
				Meal mealToAdd = (Meal) mealMenu.get(option);
				this.mealSet.add(mealToAdd);
				System.out.println(mealToAdd.getName() + " has been added to the promotion package.");
			}else{
				System.out.println("Item is not a dish");
			}
		}catch(IndexOutOfBoundsException e){
			System.out.println("Dish failed to be added! (Invalid index given)");
		}
	}
	
	public void removeMeal(Meal meal) { 
		mealSet.remove(meal); 
	}
	public void removeMeal() {
		System.out.println("Which dish do you wish to remove from the Promotion Package?");
		int j=0;
		for (Meal m : mealSet)
			System.out.println(j++ + ": " + m.getName());
    	int option = ScannerExt.nextInt("    Enter your choice: ");
		try {
			String mealNameRemoved = mealSet.get(option).getName();
			mealSet.remove(option);
			System.out.println(mealNameRemoved + " has been removed from the promotion package."); 
		}catch(IndexOutOfBoundsException e){
			System.out.println("Dish failed to be removed! (Invalid index given)");
		}
	}	
}
