package CZ2002_project;

//import java.io.Serializable;
import java.util.Date;

import classes.Invoice;
import classes.MenuItem;
import classes.OrderLineItem;
import classes.Reservation;
import classes.Staff;
import classes.Table.TableStatus;
import db.Restaurant;
import user_lib.ScannerExt;

import java.util.Calendar;
import java.io.Serializable;
import java.util.ArrayList;

//import classes.Table.TableStatus;
//import db.Restaurant;
//import user_lib.ScannerExt;

public class Order implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7445566611104977678L;
	
	private int orderNo;
	private Date dateAndTime;
	private Staff makeOrder;
	private Reservation reservationOf;
	private ArrayList<OrderList> orderList;
	private Invoice invoice; 
	
	public int getOrderNo(){ 
		return this.orderNo; 
	}
	public Date getDateAndTime() {
		return this.dateAndTime;
	}
	public Staff getStaff{
		return this.makeOrder;
	}
	public Reservation getReservationOf() {
		return this.reservationOf;
	}
	public ArrayList<OrderList> getOrderList(){
		return this.orderList;
	}
	public Invoice getInvoice() {
		return this.invoice;
	}
	
	public Order(Staff makeOrder, Reservation reservationOf){
		this.orderNo = Calendar.getInstance().hashCode();
		this.dateAndTime = Calendar.getInstance().getTime();
		this.makeOrder = makeOrder;
		this.reservationOf = reservationOf;
		this.orderList = new ArrayList<OrderList>();
		this.invoice = null;
	}
	
	public String toString(){
		String printString = "";
		for(OrderList a : orderList){
			printString += a.getMenu().getName() + "    " + a.getPriceCharged() + "\n";
		}
		return printString;
	}
	
	public void addOrder(OrderList orderMeal){
		if(this.invoice != null) return;	
		orderList.add(orderMeal);
	}
	
	public void addOrderMeal(){
		if(this.invoice != null) return;	
		int option;
		int i = 0;
		OrderList orderMeal;
		ArrayList<Menu> mealMenu = Restaurant.mealMenu;
		System.out.println("\nChoose a dish to add to order:");
		for(Menu menu : mealMenu)
			System.out.println("(" + i++ + ") " + menu.getName());
    	option = ScannerExt.nextInt("    Enter your choice: ");
		try {
			String orderMealAdded = mealMenu.get(option).getName();
			orderMeal = new OrderList(mealMenu.get(option));
			this.orderList.add(orderMeal);
			System.out.println(orderMealAdded + " added to order."); 
		}catch(IndexOutOfBoundsException e){
			System.out.println("Dish failed to be added to order! (Invalid index given)");
		}
	}
	
	public void removeOrderMeal(){
		if(this.invoice != null) return;
		int option, i=0;
		System.out.println("\nWhich dish do you wish to remove from order?");
		for (OrderList orderMeal : orderList)
			System.out.println(i++ + ": " + orderMeal.getMenu().getName());
    	option = ScannerExt.nextInt("    Enter your choice: ");
		try {
			String orderMealRemoved = orderList.get(option).toString();
			this.orderList.remove(option);
			System.out.println(orderMealRemoved + " removed from order."); 
		}catch(IndexOutOfBoundsException e){
			System.out.println("Dish failed to be removed from order! (Invalid index given");
		}
	}
	
	public double calculateRawTotal(){
		double rawTotal = 0;
		for(OrderList a : this.orderList)
			rawTotal += a.getMenu().getPrice();
		return rawTotal;
	}
	
	public void createInvoice(){
		if(this.invoice != null) return;
		this.invoice = new Invoice(this);
		this.reservationOf.getReservationOfTable().setTableStatus(StatusOfTable.EMPTY);
	}
}
